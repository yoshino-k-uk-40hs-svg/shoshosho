const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT) || 3000;
const HTML_FILE = path.join(__dirname, "..", "shogi_online_connection_fixed.html");

const rooms = new Map();

function getRoom(roomCode) {
  if (!rooms.has(roomCode)) {
    rooms.set(roomCode, {
      clients: new Set(),
      state: null,
    });
  }
  return rooms.get(roomCode);
}

function send(ws, message) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(message));
  }
}

function broadcast(room, message, except = null) {
  for (const client of room.clients) {
    if (client !== except) send(client, message);
  }
}

function sanitizeRoom(value) {
  return String(value || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, "")
    .slice(0, 32);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (url.pathname === "/health") {
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify({
      ok: true,
      rooms: rooms.size,
      clients: [...rooms.values()].reduce((n, room) => n + room.clients.size, 0),
    }));
    return;
  }

  if (url.pathname === "/" || url.pathname === "/index.html") {
    fs.readFile(HTML_FILE, (err, data) => {
      if (err) {
        res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("HTMLファイルを読み込めませんでした。");
        return;
      }
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(data);
    });
    return;
  }

  res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Not Found");
});

const wss = new WebSocket.Server({ server });

wss.on("connection", (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const roomCode = sanitizeRoom(url.searchParams.get("room"));

  if (!roomCode) {
    send(ws, { type: "error", message: "ルームコードがありません。" });
    ws.close(1008, "room required");
    return;
  }

  const room = getRoom(roomCode);

  // このHTMLは2人対戦を想定しているため、3人目以降は拒否。
  if (room.clients.size >= 2) {
    send(ws, { type: "error", message: "このルームは満員です。" });
    ws.close(1008, "room full");
    return;
  }

  room.clients.add(ws);

  ws.roomCode = roomCode;
  ws.isAlive = true;

  const updateRoom = () => {
    broadcast(room, {
      type: "room",
      players: room.clients.size,
    });
  };

  send(ws, {
    type: "room",
    players: room.clients.size,
  });

  // 先に存在していた対局状態を新規参加者へ送る。
  if (room.state) {
    send(ws, {
      type: "state",
      ...room.state,
    });
  }

  updateRoom();

  ws.on("pong", () => {
    ws.isAlive = true;
  });

  ws.on("message", (raw) => {
    let message;
    try {
      message = JSON.parse(raw.toString());
    } catch {
      send(ws, { type: "error", message: "不正なメッセージです。" });
      return;
    }

    if (!message || typeof message.type !== "string") {
      send(ws, { type: "error", message: "メッセージ形式が不正です。" });
      return;
    }

    if (message.type === "ping") {
      send(ws, { type: "pong" });
      return;
    }

    if (message.type === "state") {
      // クライアント間で共有する現在の盤面状態。
      // prototype版HTMLに合わせ、受信した状態をルームに保存して全員へ配信。
      if (!message.board || !message.turn || !message.hands) {
        send(ws, { type: "error", message: "対局状態が不足しています。" });
        return;
      }

      room.state = {
        board: message.board,
        turn: message.turn,
        hands: message.hands,
        lastMove: message.lastMove || null,
      };

      broadcast(room, {
        type: "state",
        ...room.state,
      }, ws);

      return;
    }

    if (message.type === "gameOver") {
      broadcast(room, {
        type: "gameOver",
        reason: String(message.reason || "対局が終了しました。").slice(0, 200),
      }, ws);
      return;
    }

    send(ws, {
      type: "error",
      message: `未対応のメッセージ: ${message.type}`,
    });
  });

  ws.on("close", () => {
    room.clients.delete(ws);
    updateRoom();

    if (room.clients.size === 0) {
      rooms.delete(roomCode);
    }
  });

  ws.on("error", () => {
    // closeイベントで後処理する。
  });
});

// WebSocketの死活確認。
const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) {
      ws.terminate();
      continue;
    }

    ws.isAlive = false;
    ws.ping();
  }
}, 30000);

server.on("close", () => clearInterval(heartbeat));

server.listen(PORT, () => {
  console.log(`オンライン将棋サーバー起動: http://localhost:${PORT}`);
});
