オンライン将棋サーバー版

1. Node.jsをインストール
2. このフォルダで npm install
3. npm start
4. http://localhost:3000 を開く
5. 右上の同じルームコードを2人で入力して接続

インターネット越しに公開する場合は、このNode.jsサーバーをRender/Railway/VPS等にHTTPS/WSSで公開してください。
